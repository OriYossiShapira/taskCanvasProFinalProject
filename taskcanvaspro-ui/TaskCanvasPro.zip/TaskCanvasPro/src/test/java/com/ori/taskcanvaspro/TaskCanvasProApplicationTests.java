package com.ori.taskcanvaspro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskCanvasProApplicationTests {

	@Test
	void contextLoads() {
	}

}
