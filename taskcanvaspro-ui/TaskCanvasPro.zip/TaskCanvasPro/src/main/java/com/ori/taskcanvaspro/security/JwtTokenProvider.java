package com.ori.taskcanvaspro.security;

import org.springframework.stereotype.Service;

@Service
public class JwtTokenProvider {
}
