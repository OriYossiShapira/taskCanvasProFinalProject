package com.ori.taskcanvaspro.service.validation;

public class UserValidator {
}
