package com.ori.taskcanvaspro.exeption;

public class BadRequestException {
}
