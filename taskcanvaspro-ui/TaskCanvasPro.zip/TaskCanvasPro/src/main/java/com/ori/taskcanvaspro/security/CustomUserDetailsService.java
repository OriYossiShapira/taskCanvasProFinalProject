package com.ori.taskcanvaspro.security;

public class CustomUserDetailsService {
}
